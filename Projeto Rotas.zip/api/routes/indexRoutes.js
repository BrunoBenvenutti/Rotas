const controller = require('../controllers/indexControllers.js')

app.get('/', controller.index)



